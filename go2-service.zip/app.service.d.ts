export declare class AppService {
    getHello(): string;
    getHee(): string;
}
